// JavaScript Document

$(document).ready(function() {
	alert('goddamnitall');
	

	
	
});