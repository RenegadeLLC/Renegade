
<?php
echo ('<p>Hi I am some random ' . rand() .' output from the server.</p>');
echo('wtf??');
?>